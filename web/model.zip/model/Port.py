class Port:
    def __init__(self):
        self.no = '0'
        self.cur = 0
        self.pre = 0
        self.inFlow = 0
        self.outFlow = 0